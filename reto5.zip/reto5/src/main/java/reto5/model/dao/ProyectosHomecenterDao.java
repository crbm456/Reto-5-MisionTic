package reto5.model.dao;

import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import reto5.model.vo.ProyectosHomecenterVo;
import reto5.utils.JDBCUtilities;

public class ProyectosHomecenterDao {
    public List<ProyectosHomecenterVo> listar() throws SQLException{
        List<ProyectosHomecenterVo> respuesta = new ArrayList<ProyectosHomecenterVo>();
        Connection conn = JDBCUtilities.getConnection();
        Statement stm = null;
        ResultSet rs = null;
        String consulta = "select ID_Compra as id, Constructora, Banco_Vinculado as banco from Proyecto p join Compra c on(p.ID_Proyecto = c.ID_Proyecto) where c.Proveedor = 'Homecenter' and p.Ciudad = 'Salento'";
        try{
            stm = conn.createStatement();
            rs = stm.executeQuery(consulta);
            while(rs.next()){
                ProyectosHomecenterVo vo = new ProyectosHomecenterVo();
                vo.setId(rs.getInt("id"));
                vo.setConstructora(rs.getString("constructora"));
                vo.setBanco(rs.getString("banco"));
                respuesta.add(vo);
            }
        }
        finally{
            if (rs != null){
                rs.close();
            }
            if(stm != null){
                stm.close();
            }
            if(conn !=null){
                conn.close();
            }
        }
        return respuesta;
    }
}

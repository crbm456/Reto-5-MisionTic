package reto5.controller;

import java.sql.SQLException;
import reto5.model.dao.ListaLideresDao;
import reto5.model.dao.ProyectosHomecenterDao;
import reto5.model.dao.ProyectosDao;
import reto5.model.vo.*;
import java.util.List;


public class ReportesController {
    private ListaLideresDao listaLideresDao;
    private ProyectosDao proyectosDao;
    private ProyectosHomecenterDao proyectosHomecenterDao;
    

    public ReportesController(){
        listaLideresDao = new ListaLideresDao();
        proyectosDao = new ProyectosDao();
        proyectosHomecenterDao = new ProyectosHomecenterDao();
        
    }
    public List<ListaLideresVo> listarLideres() throws SQLException{
        return listaLideresDao.listar();
    }
    public List<ProyectosVo> listarProyectos() throws SQLException{
        return proyectosDao.listar();
    }
    public List<ProyectosHomecenterVo> listarProyectosHomecenter() throws SQLException{
        return proyectosHomecenterDao.listar();
    }

    
}

